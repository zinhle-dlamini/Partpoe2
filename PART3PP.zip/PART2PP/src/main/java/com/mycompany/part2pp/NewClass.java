/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.st10445739;


import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
/**
 *
 * @author Zinhle
 */

public class NewClass extends JFrame{
  



    private final ArrayList<String> developers = new ArrayList<>();
    private final ArrayList<String> taskNames = new ArrayList<>();
    private final ArrayList<String> taskIDs = new ArrayList<>();
    private final ArrayList<Integer> taskDurations = new ArrayList<>();
    private final ArrayList<String> taskStatuses = new ArrayList<>();

    public NewClass() {
        setTitle("Task Manager - ST10456413");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(7, 1, 10, 10));

        JButton btnAddData = new JButton("Add Test Data");
        JButton btnDisplayDone = new JButton("Display Done Tasks");
        JButton btnLongestTask = new JButton("Longest Task Duration");
        JButton btnSearchTask = new JButton("Search Task by Name");
        JButton btnSearchByDeveloper = new JButton("Search Tasks by Developer");
        JButton btnDeleteTask = new JButton("Delete Task by Name");
        JButton btnDisplayReport = new JButton("Display All Tasks Report");

        btnAddData.addActionListener(e -> populateTestData());
        btnDisplayDone.addActionListener(e -> displayDoneTasks());
        btnLongestTask.addActionListener(e -> displayLongestTask());
        btnSearchTask.addActionListener(e -> searchTaskByName());
        btnSearchByDeveloper.addActionListener(e -> searchTasksByDeveloper());
        btnDeleteTask.addActionListener(e -> deleteTaskByName());
        btnDisplayReport.addActionListener(e -> displayReport());

        mainPanel.add(btnAddData);
        mainPanel.add(btnDisplayDone);
        mainPanel.add(btnLongestTask);
        mainPanel.add(btnSearchTask);
        mainPanel.add(btnSearchByDeveloper);
        mainPanel.add(btnDeleteTask);
        mainPanel.add(btnDisplayReport);

        add(mainPanel, BorderLayout.CENTER);
    }

    private void populateTestData() {
        developers.clear();
        taskNames.clear();
        taskIDs.clear();
        taskDurations.clear();
        taskStatuses.clear();

        developers.add("Micheal Jackson");
        taskNames.add("Create Login");
        taskIDs.add("T1");
        taskDurations.add(5);
        taskStatuses.add("To Do");

        developers.add("William Smith");
        taskNames.add("Create Add Features");
        taskIDs.add("T2");
        taskDurations.add(8);
        taskStatuses.add("Doing");

        developers.add("Hailey Berry");
        taskNames.add("Create Reports");
        taskIDs.add("T3");
        taskDurations.add(2);
        taskStatuses.add("Done");

        developers.add("Brenda Fassie");
        taskNames.add("Add Arrays");
        taskIDs.add("T4");
        taskDurations.add(11);
        taskStatuses.add("To Do");

        JOptionPane.showMessageDialog(this, "Test data added successfully!");
    }

    private void displayDoneTasks() {
        StringBuilder result = new StringBuilder("Tasks with status 'Done':\n");
        boolean found = false;

        for (int i = 0; i < taskStatuses.size(); i++) {
            if ("Done".equalsIgnoreCase(taskStatuses.get(i))) {
                result.append("Developer: ").append(developers.get(i))
                        .append(", Task Name: ").append(taskNames.get(i))
                        .append(", Duration: ").append(taskDurations.get(i)).append("\n");
                found = true;
            }
        }

        if (!found) {
            result.append("No tasks with status 'Done'.");
        }

        JOptionPane.showMessageDialog(this, result.toString());
    }

    private void displayLongestTask() {
        if (taskDurations.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tasks available.");
            return;
        }

        int maxDurationIndex = 0;

        for (int i = 1; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > taskDurations.get(maxDurationIndex)) {
                maxDurationIndex = i;
            }
        }

        JOptionPane.showMessageDialog(this,
                "Developer: " + developers.get(maxDurationIndex) +
                        ", Task Name: " + taskNames.get(maxDurationIndex) +
                        ", Duration: " + taskDurations.get(maxDurationIndex));
    }

    private void searchTaskByName() {
        String taskName = JOptionPane.showInputDialog(this, "Enter Task Name:");
        if (taskName == null || taskName.isEmpty()) {
            return;
        }

        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                JOptionPane.showMessageDialog(this,
                        "Task Name: " + taskNames.get(i) +
                                ", Developer: " + developers.get(i) +
                                ", Status: " + taskStatuses.get(i));
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Task not found!");
    }

    private void searchTasksByDeveloper() {
        String developerName = JOptionPane.showInputDialog(this, "Enter Developer Name:");
        if (developerName == null || developerName.isEmpty()) {
            return;
        }

        StringBuilder result = new StringBuilder("Tasks for " + developerName + ":\n");
        boolean found = false;

        for (int i = 0; i < developers.size(); i++) {
            if (developers.get(i).equalsIgnoreCase(developerName)) {
                result.append("Task Name: ").append(taskNames.get(i))
                        .append(", Status: ").append(taskStatuses.get(i)).append("\n");
                found = true;
            }
        }

        if (found) {
            JOptionPane.showMessageDialog(this, result.toString());
        } else {
            JOptionPane.showMessageDialog(this, "No tasks found for " + developerName + "!");
        }
    }

    private void deleteTaskByName() {
        String taskName = JOptionPane.showInputDialog(this, "Enter Task Name to Delete:");
        if (taskName == null || taskName.isEmpty()) {
            return;
        }

        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(taskName)) {
                developers.remove(i);
                taskNames.remove(i);
                taskIDs.remove(i);
                taskDurations.remove(i);
                taskStatuses.remove(i);
                JOptionPane.showMessageDialog(this, "Task '" + taskName + "' deleted successfully!");
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Task not found!");
    }

    private void displayReport() {
        if (taskNames.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tasks to display.");
            return;
        }

        StringBuilder report = new StringBuilder("All Tasks Report:\n");

        for (int i = 0; i < taskNames.size(); i++) {
            report.append("Task ID: ").append(taskIDs.get(i))
                    .append(", Task Name: ").append(taskNames.get(i))
                    .append(", Developer: ").append(developers.get(i))
                    .append(", Duration: ").append(taskDurations.get(i))
                    .append(", Status: ").append(taskStatuses.get(i)).append("\n");
        }

        JOptionPane.showMessageDialog(this, report.toString());
    }

    // This is the main method, which launches the application
    public static void main(String[] args) {
        // Create and show the frame
        NewClass taskManager = new NewClass();
        taskManager.setVisible(true);  // Make it visible
    }
}

